import React from 'react';
import {View, Text, StyleSheet, Image, TouchableOpacity} from 'react-native';
import {
  ThumbsUp,
  MessageCircle,
  Share2,
  Send,
  Forward,
  MessageCircleMore,
  X,
  MoreVertical,
  MoreHorizontal,
} from 'lucide-react-native';

interface FeedPostProps {
  username: string;
  postTime: string;
  postText: string;
  imageUrl: string;
  likes?: number;
  comments?: number;
  isLast?: boolean;
}

const FeedPost = ({
  username,
  postTime,
  postText,
  imageUrl,
  likes = 0,
  comments = 0,
  isLast = false,
}: FeedPostProps) => {
  return (
    <View style={[styles.feedPost, isLast && styles.lastFeedPost]}>
      <View
        style={{
          flex: 1,
          flexDirection: 'row',
          justifyContent: 'space-between',
          paddingHorizontal: 15,
        }}>
        <View style={styles.postHeader}>
          <Image source={{uri: imageUrl}} style={styles.avatar} />
          <View>
            <Text style={styles.username}>{username}</Text>
            <Text style={styles.postTime}>{postTime}</Text>
          </View>
        </View>
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            gap: 6,
          }}>
          <TouchableOpacity>
            <MoreHorizontal size={22} color={'#000'} />
          </TouchableOpacity>
          <TouchableOpacity>
            <X size={22} color={'#000'} />
          </TouchableOpacity>
        </View>
      </View>
      <View
        style={{
          paddingHorizontal: 15,
          width: '100%',
        }}>
        <Text style={styles.postText}>{postText}</Text>
      </View>
      <Image source={{uri: imageUrl}} style={styles.postImage} />

      <View style={styles.interactionBar}>
        <View style={styles.interactionStats}>
          <ThumbsUp size={16} color="#1877F2" />
          <Text style={styles.interactionText}>{likes}</Text>
        </View>
        <View style={styles.interactionStats}>
          <Text style={styles.interactionText}>{comments} comments</Text>
        </View>
      </View>

      <View style={styles.actionButtons}>
        <TouchableOpacity style={styles.actionButton}>
          <ThumbsUp size={24} color="#65676B" />
          <Text style={styles.actionButtonText}>Like</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.actionButton}>
          <MessageCircle size={24} color="#65676B" />
          <Text style={styles.actionButtonText}>Comment</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.actionButton}>
          <MessageCircleMore size={24} color="#65676B" />
          <Text style={styles.actionButtonText}>Send</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.actionButton}>
          <Forward size={24} color="#65676B" />
          <Text style={styles.actionButtonText}>Share</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  feedPost: {
    backgroundColor: '#fff',
    marginBottom: 10,
    borderBottomWidth: 3,
    borderBottomColor: '#ccc',
  },
  lastFeedPost: {
    borderBottomWidth: 0,
  },
  postHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  avatar: {
    width: 50,
    height: 50,
    borderRadius: 25,
    marginRight: 10,
  },
  username: {
    fontWeight: 'bold',
  },
  postTime: {
    fontSize: 12,
    color: '#666',
  },
  postText: {
    marginBottom: 10,
  },
  postImage: {
    width: '100%',
    height: 250,
    // borderRadius: 10,
  },
  interactionBar: {
    flexDirection: 'row',
    paddingHorizontal: 10,

    justifyContent: 'space-between',
    paddingVertical: 10,
    // borderBottomWidth: 1,
    // borderBottomColor: '#E4E6EB',
  },
  interactionStats: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  interactionText: {
    marginLeft: 5,
    color: '#65676B',
    fontSize: 14,
  },
  actionButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 10,
    paddingHorizontal: 15,
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    flex: 1,
  },
  actionButtonText: {
    marginLeft: 5,
    color: '#65676B',
    fontSize: 14,
  },
});

export default FeedPost;
