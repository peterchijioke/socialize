import React from 'react';
import {View, StyleSheet, FlatList} from 'react-native';
import FeedPost from './FeedPost';

interface Post {
  id: number;
  username: string;
  postTime: string;
  postText: string;
  imageUrl: string;
  likes?: number;
  comments?: number;
}

const Feed = () => {
  const image_url = 'https://github.com/shadcn.png';

  const posts: Post[] = [
    {
      id: 1,
      username: 'Jennifer John',
      postTime: '8h • 🌍',
      postText:
        '50k each to 3 Financial Women coming on this money journey with me 🎉🎉',
      imageUrl: image_url,
      likes: 245,
      comments: 32,
    },
    {
      id: 2,
      username: 'Tech Enthusiast',
      postTime: '5h • 🌐',
      postText:
        'Just finished building my first React Native app! The journey has been amazing. #coding #reactnative',
      imageUrl: image_url,
      likes: 189,
      comments: 24,
    },
    {
      id: 3,
      username: 'Travel Explorer',
      postTime: '2h • 🌎',
      postText:
        'Beautiful sunset at the beach today! Nature never fails to amaze me. 🌅',
      imageUrl: image_url,
      likes: 432,
      comments: 56,
    },
    {
      id: 4,
      username: 'Food Lover',
      postTime: '1h • 🍽️',
      postText:
        'Made this delicious pasta from scratch today! Recipe in comments 👇',
      imageUrl: image_url,
      likes: 156,
      comments: 18,
    },
  ];

  const renderPost = ({item, index}: {item: Post; index: number}) => (
    <FeedPost
      isLast={index === posts.length - 1}
      username={item.username}
      postTime={item.postTime}
      postText={item.postText}
      imageUrl={item.imageUrl}
      likes={item.likes}
      comments={item.comments}
    />
  );

  return (
    <View style={styles.container}>
      <FlatList
        data={posts}
        renderItem={renderPost}
        keyExtractor={item => item.id.toString()}
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    width: '100%',
    gap: 10,
  },
});

export default Feed;
